/*

Sterownik silnika BLDC.
Test pod��czonego symulatora lub silnika.

Cz�stotliwo�� F_CPU: dowolna (ustaw w opcjach projektu)

Szczeg�y: http://mikrokontrolery.blogspot.com/2011/03/silnik-bldc-podlaczamy-testujemy.html

2012 Dondu

*/


#include <avr/io.h>
#include <util/delay.h>
#include "bldc.h"


//------------------------------------------------------------------

int main (void) 
{

	//inicjujemy sterownik
	bldc_inicjuj_sterownik();

	//p�tla g��wna
	while(1){
		
		bldc_komutacja();

		//odst�p komutacji reguluje pr�dko�� obrot�w
		_delay_ms(12);	
	
	}	

}






