/*

Plik:	main.c

Sterownik silnika BLDC.
Sterowanie silnikiem z wykorzystaniem czujnik�w Halla

Cz�stotliwo�� F_CPU: co najmniej 1MHz (ustaw w opcjach projektu)
					 ale w zale�no�ci od cz�stotliwo��i powiniene� dobra�
					 preskalery timer�w - szczeg�y w artylkule

Szczeg�y: http://mikrokontrolery.blogspot.com/2011/03/Silnik-BLDC-Czujniki-Halla-sterowanie.html

Dondu, 05 marca 2014r.

*/


#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "bldc.h"


//------------------------------------------------------------------

int main (void) 
{

	//op�nienie na ustabilizowanie zasilania (mo�na usun��)
	_delay_ms(10);

	//inicjujemy sterownik BLDC
	bldc_hall_inicjuj_sterownik();

	//uruchom silnik
	bldc_start();

	//p�tla g��wna
	while(1){
		
		//Tutaj Tw�j program ....
		
		
		/* Odkomentuj by uruchomi� przyk�ad

		//--- P R Z Y K � A D ----
		//Przyk�ad zmieniaj�cy pr�dko�� obrotow� silnika
		//ustaw now� warto�� PWM w celu zmiany pr�dko�ci
		OCR1A	=	PWM_MIN;
		OCR1B	=	PWM_MIN;
		OCR2	=	PWM_MIN;
		_delay_ms(5000);
		

		//ustaw now� warto�� PWM w celu zmiany pr�dko�ci
		OCR1A	=	PWM_MAX;
		OCR1B	=	PWM_MAX;
		OCR2	=	PWM_MAX;
		_delay_ms(2000);

		*/


	}	
}






