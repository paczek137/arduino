/*************************************************************************
* SmartPIP - Elektroniczny dr�czyciel
* 
* Data:  kwiecie� 2013
* Autor: Dondu
* www:   http://mikrokontrolery.blogspot.com/2011/04/SmartPIP-elektroniczny-dreczyciel-spis-tresci.html
* 
* Plik:  dd_usart.h
* Opis:  Plik nag��wkowy pliku dd_usart.c
*************************************************************************/

//USART - tablica bufora wysy�ki oraz zmienna indeksu tablicy
#define USART_BUFOR_DLUGOSC		30				//rozmiar bufora
extern char usart_bufor[USART_BUFOR_DLUGOSC];	//bufor
extern volatile unsigned int usart_bufor_ind;	//indeks bufora

//Funkcje
extern void usart_inicjuj(void);
extern void usart_wyslij_bufor(void);


