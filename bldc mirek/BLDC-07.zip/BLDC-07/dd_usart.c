/*************************************************************************
* SmartPIP - Elektroniczny dr�czyciel
* 
* Data:  kwiecie� 2013
* Autor: Dondu
* www:   http://mikrokontrolery.blogspot.com/2011/04/SmartPIP-elektroniczny-dreczyciel-spis-tresci.html
* 
* Plik:  dd_usart.c
* Opis:  Funkcje komunikacji RS-232
*************************************************************************/


#include <avr/io.h>
#include <avr/interrupt.h>

#include "dd_usart.h"

//USART - tablica bufora wysy�ki oraz zmienna indeksu tablicy
char usart_bufor[USART_BUFOR_DLUGOSC] = "Testowanie czujnika swiatla:"; 
volatile unsigned int usart_bufor_ind;


//--------------------------------------------------------------

void usart_inicjuj(void)
{
 //definiowanie parametr�w transmisji za pomoc� makr zawartych w pliku
 //nag��wkowym setbaud.h. Je�eli wybierzesz pr�dko��, kt�ra nie b�dzie 
 //mo�liwa do realizacji otrzymasz ostrze�enie: 
 //#warning "Baud rate achieved is higher than allowed"

 #define BAUD 9600         //tutaj podaj ��dan� pr�dko�� transmisji
 #include <util/setbaud.h>  //linkowanie tego pliku musi by� 
                            //po zdefiniowaniu BAUD
 
 //ustaw obliczone przez makro warto�ci
 UBRRH = UBRRH_VALUE;  
 UBRRL = UBRRL_VALUE;
 #if USE_2X
    UCSRA |= (1 << U2X);
 #else
    UCSRA &= ~(1 << U2X);
 #endif

 //Ustawiamy pozosta�e parametry modu� USART
 //zobacz: http://mikrokontrolery.blogspot.com/2011/04/Pulapki-AVR-Rejestry-pod-tym-samym-adresem.html 
 UCSRC = (1<<URSEL) | (1<<UCSZ1) | (1<<UCSZ0);   //bit�w danych: 8
                                                 //bity stopu:  1
                                                 //parzysto��:  brak
 //w��cz nadajnik
 UCSRB |= (1<<TXEN);
}





//--------------------------------------------------------------

ISR(USART_UDRE_vect){


}

