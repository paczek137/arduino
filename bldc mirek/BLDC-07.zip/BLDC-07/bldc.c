/*

Plik:	bldc.c

Sterownik silnika BLDC.
Sterowanie silnikiem z wykorzystaniem czujnik�w Halla

Cz�stotliwo�� F_CPU: co najmniej 1MHz (ustaw w opcjach projektu)
					 ale w zale�no�ci od cz�stotliwo��i powiniene� dobra�
					 preskalery timer�w - szczeg�y w artylkule

Szczeg�y: http://mikrokontrolery.blogspot.com/2011/03/Silnik-BLDC-Czujniki-Halla-sterowanie.html

Dondu, 05 marca 2014r.

*/


#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "bldc.h"


//--------------------------------------------------------------------

void bldc_bezpiecznik_stop(void){

	//Funkcja wy��cza wszelkie tranzystory oraz przechodzi w stan sygnalizacji
	//b��du komutacji. Funkcja ta razem z funkcj� bezpiecznik() pe�ni rol�
	//zabezpieczenia przeciwzwarciowego dla b��dnie dzia�aj�cego algorytmu
	//komutacji w czasie pisania i test�w programu.

	//wy��cz przerwania
	cli();

	//natychmiast wy��cz tranzystory
	WYLACZ_TRANZYSTORY

	//i ustaw stany niskie na pinach steruj�cych 
	U_TR_G_USTAW_DDR
	V_TR_G_USTAW_DDR
	W_TR_G_USTAW_DDR
	U_TR_D_USTAW_DDR
	V_TR_D_USTAW_DDR
	W_TR_D_USTAW_DDR
	U_TR_G_PIN_L
	V_TR_G_PIN_L
	W_TR_G_PIN_L
	U_TR_D_PIN_L
	V_TR_D_PIN_L
	W_TR_D_PIN_L

	//ustaw pin LED jako wyj�cie
	BEZP_LED_DDR	|=	(1<<BEZP_LED_PIN);

	//zatrzymaj program w p�tli niesko�czonej sygnalizuj�c b��d 
	while(1){ 

		//zmie� stan LED na przeciwny
		BEZP_LED_PORT  ^= (1<<BEZP_LED_PIN);		

		//co 100ms
		_delay_ms(100);

	}
}


//--------------------------------------------------------------------

void bldc_start(void){

	//Funkcja odpowiedzialna za:
	//1. pozycjnowanie wirnika przed uruchomieniem silnika,
	//2. wykonanie ruchu silnikiem w kierunku obrot�w, co ma 
	//   zainicjowa� start silnika

	//W funkcji u�ywamy op�nie�, kt�re nale�y odpowiednio wyd�u�y�, 
	//je�li wirnik silnika ma du�� bezw�adno��

	//ustaw wype�nienie podczas startu (wymagana du�a moc silnika)
	OCR1A	=	PWM_START;
	OCR1B	=	PWM_START;
	OCR2	=	PWM_START;

	//pozycjonowanie wirnika
	V_TR_D_ON
	W_TR_G_ON
	bldc_bezpiecznik();
	_delay_ms(1000);	//odczekaj na przekr�cenie si� wirnika
						//do pozycji startowej

	//wy��cz tranzystory
	V_TR_D_OFF
	W_TR_G_OFF

	//w��cz przerwania
	sei();

	//start poprzez zakr�cenie wirnikiem w odpowiednim kierunku
	//reszt� zrobi� ju� funkcje przerwa�
	U_TR_G_ON
	V_TR_D_ON		
	bldc_bezpiecznik();
	_delay_ms(25);	

}



//------------------------------------------------------------------

void bldc_bezpiecznik(void){



	//Sprawdzamy, czy nie wyst�puje konflikt sterowania, powoduj�cy
	//jednoczene otwarcie tranzystora g�rnego i dolnego w tej samej fazie,
	//co oznacza wyst�pienie zwarcia !!!

	if(U_TR_G_SPRAW_STAN && U_TR_D_SPRAW_STAN){

		//Faza U - oba tranzystory s� w��czone - sytuacja niedopuszczalna!!!
		bldc_bezpiecznik_stop();


	}else if(V_TR_G_SPRAW_STAN && V_TR_D_SPRAW_STAN){

		//Faza V - oba tranzystory s� w��czone - sytuacja niedopuszczalna!!!
		bldc_bezpiecznik_stop();

		
	}else if(W_TR_G_SPRAW_STAN && W_TR_D_SPRAW_STAN){

		//Faza W - oba tranzystory s� w��czone - sytuacja niedopuszczalna!!!
		bldc_bezpiecznik_stop();

	}

}



//-----------------------------------------------------------


void bldc_hall_inicjuj_sterownik(void){

	//Funkcja inicjuj�ca prac� sterownika.
	//-konfiguruje wszystkie wykorzystywane modu�y mikrokontrolera
	//-ustawia piny mikrokontrolera tak, by wszystkie tranzystory
	// by�y wy��czone
	//-ustawia licznikia PWM na pocz�tkow� warto�� DutyCycle

	//ustaw stan pocz�tkowy wyj�� steruj�cych tranzystorami
	U_TR_G_USTAW_DDR
	V_TR_G_USTAW_DDR
	W_TR_G_USTAW_DDR
	U_TR_D_USTAW_DDR
	V_TR_D_USTAW_DDR
	W_TR_D_USTAW_DDR
	U_TR_G_PIN_L
	V_TR_G_PIN_L
	W_TR_G_PIN_L
	U_TR_D_PIN_L
	V_TR_D_PIN_L
	W_TR_D_PIN_L

	

	//sprawdzamy, czy nie ma stanu zabronionego na tranzystorach
	//ZAWSZE WYWO�UJ T� FUNKCJ�, GDY ZMIENIASZ STAN TRANZYSTOR�W!!!
	bldc_bezpiecznik();



	//--- T I M E R Y    P W M   -------------------

	//Timer1
	//Obs�uga PWM dla wyj�� OC1A oraz OC1B
	//Mode 5 (Fast PWM, 8bit)  
	//Clear OC1A/OC1B on Compare Match, set OC1A/OC1B at BOTTOM, 
	//(non-inverting mode)
	//preskaler 1
	TCCR1A	|=	(1<<WGM10) | (1<<COM1A1) | (1<<COM1B1);
	TCCR1B	|=	(1<<WGM12) | (1<<CS10);
	 
	
	//Timer2
	//Obs�uga PWM  dla wyj�cia OC2
	//Mode 3 (Fast PWM, 8bit)  
	//Clear OC2 on Compare Match, set OC2 at BOTTOM, (non-inverting mode)
	//preskaler 1
	TCCR2	|=	(1<<WGM21) | (1<<WGM20) | (1<<COM21) | (1<<CS20);

	//ustaw warto�� pocz�tkow� PWM
	OCR1A 	= PWM_MIN;
	OCR1B 	= PWM_MIN;
	OCR2 	= PWM_MIN;


	//--- K O M P A R A T O R ---
	//Wykrywanie zboczy sygna�u czujnika Halla fazy W
	
	//napi�cie referencyjne komparatora na wej�cie AIN0
	ACSR	|=	(1<<ACBG);	//w��cz BANDGAP na AIN0
	
	//wej�cie AIN1 czujnika fazy W
	DDRD	&= ~(1<<PD7);	//pin jako wej�cie
	
	//zbocze komparatora
	//dowolne zbocze jest domy�lnie ustawione po resecie
	//nie musimy nic ustawia�, ale na wszelki wypadek
	KOMP_ZBOCZE_DOWOLNE;	//dowolne zbocze

	//w��cz przerwania z komparatora
	ACSR	|= 	(1<<ACIE);


	
	//--- P r z e r w a n i a  INT0 i INT1 ---
	//Wykrywanie zboczy sygna��w czujnik�w Halla faz U oraz V

	DDRD	&= ~((1<<PD3) | (1<<PD2));	//INT0 i INT1 jako wej�cia
	MCUCR 	|= INT1_ZBOCZE_DOWOLNE | INT0_ZBOCZE_DOWOLNE;	//oba zbocza
	GICR 	|= (1<<INT1) | (1<<INT0);	//w��cz przerwania


	//na wszelki wypadek
	WYLACZ_TRANZYSTORY
	bldc_bezpiecznik();

}


//-----------------------------------------------------------


ISR (INT0_vect){

	//Przerwanie czujnika fazy U
	//odpowiada za dokonanie nast�pnej komutacji

	//w zale�no�ci, kt�re zbocze sygna�u U
	if((PIND & (1<<PD2))){

		//Komutacja nr 4

		//wy��cz tranzystory
		U_TR_G_OFF
		V_TR_D_OFF		
		W_TR_G_OFF
		W_TR_D_OFF		

		//w��cz tranzystory
		U_TR_D_ON
		V_TR_G_ON

		bldc_bezpiecznik();

	}else{

		//Komutacja nr 1

		//wy��cz tranzystory
		U_TR_D_OFF		
		V_TR_G_OFF
		W_TR_G_OFF
		W_TR_D_OFF		

		//w��cz tranzystory
		U_TR_G_ON
		V_TR_D_ON

		bldc_bezpiecznik();		

	}

}

//-----------------------------------------------------------


ISR (INT1_vect){

	//Przerwanie czujnika fazy V
	//odpowiada za dokonanie nast�pnej komutacji

	//w zale�no�ci, kt�re zbocze sygna�u V
	if(PIND & (1<<PD3)){

		//Komutacja nr 2
		
		//wy��cz tranzystory
		U_TR_D_OFF		
		V_TR_G_OFF
		V_TR_D_OFF		
		W_TR_G_OFF

		//w��cz tranzystory
		U_TR_G_ON
		W_TR_D_ON

		bldc_bezpiecznik();	

	}else{

		//Komutacja nr 5

		//wy��cz tranzystory
		U_TR_G_OFF
		V_TR_G_OFF
		V_TR_D_OFF		
		W_TR_D_OFF		

		//w��cz tranzystory
		U_TR_D_ON		
		W_TR_G_ON

		bldc_bezpiecznik();

	}
}


//-----------------------------------------------------------


ISR (ANA_COMP_vect){
	
	//Przerwanie czujnika fazy W
	//odpowiada za dokonanie nast�pnej komutacji

	//UWAGA!!! Sygna� ten jest zanegowany w przeciwie�stwie do fazy U i V
	//poniewa� Hallotron fazy W pod��czony jest do wej�cia odwracaj�cego
	//komparatora. Dlatego te� komutacje s� zamienione miejscami (3 z 6)

	//w zale�no�ci, kt�re zbocze sygna�u W
	if(KOMP_STAN_AKT){

		//Komutacja nr 3

		//wy��cz tranzystory
		U_TR_G_OFF
		U_TR_D_OFF		
		V_TR_D_OFF		
		W_TR_G_OFF

		//w��cz tranzystory
		V_TR_G_ON
		W_TR_D_ON

		bldc_bezpiecznik();		

	}else{
	
		//Komutacja nr 6

		//wy��cz tranzystory
		U_TR_G_OFF
		U_TR_D_OFF		
		V_TR_G_OFF
		W_TR_D_OFF		

		//w��cz tranzystory
		V_TR_D_ON
		W_TR_G_ON

		bldc_bezpiecznik();

	}
}

