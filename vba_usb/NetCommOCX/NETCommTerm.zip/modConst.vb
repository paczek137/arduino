Option Strict Off
Option Explicit On
Module modConst
	
	'--- Public variables
	Public Echo As Boolean 'Echo On/Off flag
	Public CancelSend As Boolean 'Flag to stop sending
	'  a text file.
End Module