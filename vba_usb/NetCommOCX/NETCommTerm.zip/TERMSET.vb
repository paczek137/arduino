Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmConfigScrn
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents lstRate As System.Windows.Forms.ListBox
    Public WithEvents Frame1 As System.Windows.Forms.GroupBox
    Public WithEvents OKButton As System.Windows.Forms.Button
    Public WithEvents CancelButton_Renamed As System.Windows.Forms.Button
    Public WithEvents Data7 As System.Windows.Forms.RadioButton
    Public WithEvents Data8 As System.Windows.Forms.RadioButton
    Public WithEvents Frame2 As System.Windows.Forms.GroupBox
    Public WithEvents Stop1 As System.Windows.Forms.RadioButton
    Public WithEvents Stop2 As System.Windows.Forms.RadioButton
    Public WithEvents Frame3 As System.Windows.Forms.GroupBox
    Public WithEvents EchoOff As System.Windows.Forms.RadioButton
    Public WithEvents EchoOn As System.Windows.Forms.RadioButton
    Public WithEvents Frame7 As System.Windows.Forms.GroupBox
    Public WithEvents NoParity As System.Windows.Forms.RadioButton
    Public WithEvents OddParity As System.Windows.Forms.RadioButton
    Public WithEvents EvenParity As System.Windows.Forms.RadioButton
    Public WithEvents Frame4 As System.Windows.Forms.GroupBox
    Public WithEvents lstCommPort As System.Windows.Forms.ListBox
    Public WithEvents Frame6 As System.Windows.Forms.GroupBox
    Public WithEvents NoFlow As System.Windows.Forms.RadioButton
    Public WithEvents XonFlow As System.Windows.Forms.RadioButton
    Public WithEvents RTSFlow As System.Windows.Forms.RadioButton
    Public WithEvents BothFlow As System.Windows.Forms.RadioButton
    Public WithEvents Frame5 As System.Windows.Forms.GroupBox
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmConfigScrn))
        Me.components = New System.ComponentModel.Container()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
        Me.ToolTip1.Active = True
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.lstRate = New System.Windows.Forms.ListBox()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.CancelButton_Renamed = New System.Windows.Forms.Button()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.Data7 = New System.Windows.Forms.RadioButton()
        Me.Data8 = New System.Windows.Forms.RadioButton()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.Stop1 = New System.Windows.Forms.RadioButton()
        Me.Stop2 = New System.Windows.Forms.RadioButton()
        Me.Frame7 = New System.Windows.Forms.GroupBox()
        Me.EchoOff = New System.Windows.Forms.RadioButton()
        Me.EchoOn = New System.Windows.Forms.RadioButton()
        Me.Frame4 = New System.Windows.Forms.GroupBox()
        Me.NoParity = New System.Windows.Forms.RadioButton()
        Me.OddParity = New System.Windows.Forms.RadioButton()
        Me.EvenParity = New System.Windows.Forms.RadioButton()
        Me.Frame6 = New System.Windows.Forms.GroupBox()
        Me.lstCommPort = New System.Windows.Forms.ListBox()
        Me.Frame5 = New System.Windows.Forms.GroupBox()
        Me.NoFlow = New System.Windows.Forms.RadioButton()
        Me.XonFlow = New System.Windows.Forms.RadioButton()
        Me.RTSFlow = New System.Windows.Forms.RadioButton()
        Me.BothFlow = New System.Windows.Forms.RadioButton()
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Text = "Communication Settings"
        Me.ClientSize = New System.Drawing.Size(332, 256)
        Me.Location = New System.Drawing.Point(74, 102)
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Icon = CType(resources.GetObject("frmConfigScrn.Icon"), System.Drawing.Icon)
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 13)
        Me.ControlBox = True
        Me.Enabled = True
        Me.KeyPreview = False
        Me.MaximizeBox = True
        Me.MinimizeBox = True
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = True
        Me.HelpButton = False
        Me.WindowState = System.Windows.Forms.FormWindowState.Normal
        Me.Name = "frmConfigScrn"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Window
        Me.Frame1.Text = "&Baud Rate"
        Me.Frame1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame1.Size = New System.Drawing.Size(85, 65)
        Me.Frame1.Location = New System.Drawing.Point(16, 8)
        Me.Frame1.TabIndex = 2
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.Enabled = True
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Visible = True
        Me.Frame1.Name = "Frame1"
        Me.lstRate.Size = New System.Drawing.Size(73, 33)
        Me.lstRate.Location = New System.Drawing.Point(6, 18)
        Me.lstRate.TabIndex = 23
        Me.lstRate.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstRate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lstRate.BackColor = System.Drawing.SystemColors.Window
        Me.lstRate.CausesValidation = True
        Me.lstRate.Enabled = True
        Me.lstRate.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstRate.IntegralHeight = True
        Me.lstRate.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstRate.SelectionMode = System.Windows.Forms.SelectionMode.One
        Me.lstRate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstRate.Sorted = False
        Me.lstRate.TabStop = True
        Me.lstRate.Visible = True
        Me.lstRate.MultiColumn = False
        Me.lstRate.Name = "lstRate"
        Me.OKButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.OKButton.BackColor = System.Drawing.SystemColors.Control
        Me.OKButton.Text = "OK"
        Me.AcceptButton = Me.OKButton
        Me.OKButton.Size = New System.Drawing.Size(65, 25)
        Me.OKButton.Location = New System.Drawing.Point(234, 26)
        Me.OKButton.TabIndex = 0
        Me.OKButton.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OKButton.CausesValidation = True
        Me.OKButton.Enabled = True
        Me.OKButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.OKButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.OKButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OKButton.TabStop = True
        Me.OKButton.Name = "OKButton"
        Me.CancelButton_Renamed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.CancelButton_Renamed.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.CancelButton_Renamed
        Me.CancelButton_Renamed.Text = "Cancel"
        Me.CancelButton_Renamed.Size = New System.Drawing.Size(65, 25)
        Me.CancelButton_Renamed.Location = New System.Drawing.Point(234, 58)
        Me.CancelButton_Renamed.TabIndex = 1
        Me.CancelButton_Renamed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelButton_Renamed.CausesValidation = True
        Me.CancelButton_Renamed.Enabled = True
        Me.CancelButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CancelButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
        Me.CancelButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CancelButton_Renamed.TabStop = True
        Me.CancelButton_Renamed.Name = "CancelButton_Renamed"
        Me.Frame2.BackColor = System.Drawing.SystemColors.Window
        Me.Frame2.Text = "&Data Bits"
        Me.Frame2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame2.Size = New System.Drawing.Size(85, 41)
        Me.Frame2.Location = New System.Drawing.Point(16, 84)
        Me.Frame2.TabIndex = 3
        Me.Frame2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame2.Enabled = True
        Me.Frame2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame2.Visible = True
        Me.Frame2.Name = "Frame2"
        Me.Data7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Data7.BackColor = System.Drawing.SystemColors.Window
        Me.Data7.Text = "7"
        Me.Data7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Data7.Size = New System.Drawing.Size(25, 17)
        Me.Data7.Location = New System.Drawing.Point(8, 16)
        Me.Data7.TabIndex = 4
        Me.Data7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Data7.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Data7.CausesValidation = True
        Me.Data7.Enabled = True
        Me.Data7.Cursor = System.Windows.Forms.Cursors.Default
        Me.Data7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Data7.Appearance = System.Windows.Forms.Appearance.Normal
        Me.Data7.TabStop = True
        Me.Data7.Checked = False
        Me.Data7.Visible = True
        Me.Data7.Name = "Data7"
        Me.Data8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Data8.BackColor = System.Drawing.SystemColors.Window
        Me.Data8.Text = "8"
        Me.Data8.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Data8.Size = New System.Drawing.Size(29, 17)
        Me.Data8.Location = New System.Drawing.Point(46, 16)
        Me.Data8.TabIndex = 5
        Me.Data8.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Data8.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Data8.CausesValidation = True
        Me.Data8.Enabled = True
        Me.Data8.Cursor = System.Windows.Forms.Cursors.Default
        Me.Data8.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Data8.Appearance = System.Windows.Forms.Appearance.Normal
        Me.Data8.TabStop = True
        Me.Data8.Checked = False
        Me.Data8.Visible = True
        Me.Data8.Name = "Data8"
        Me.Frame3.BackColor = System.Drawing.SystemColors.Window
        Me.Frame3.Text = "&Stop Bits"
        Me.Frame3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame3.Size = New System.Drawing.Size(89, 41)
        Me.Frame3.Location = New System.Drawing.Point(116, 84)
        Me.Frame3.TabIndex = 6
        Me.Frame3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame3.Enabled = True
        Me.Frame3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame3.Visible = True
        Me.Frame3.Name = "Frame3"
        Me.Stop1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Stop1.BackColor = System.Drawing.SystemColors.Window
        Me.Stop1.Text = "1"
        Me.Stop1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Stop1.Size = New System.Drawing.Size(29, 17)
        Me.Stop1.Location = New System.Drawing.Point(8, 16)
        Me.Stop1.TabIndex = 7
        Me.Stop1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stop1.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Stop1.CausesValidation = True
        Me.Stop1.Enabled = True
        Me.Stop1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Stop1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Stop1.Appearance = System.Windows.Forms.Appearance.Normal
        Me.Stop1.TabStop = True
        Me.Stop1.Checked = False
        Me.Stop1.Visible = True
        Me.Stop1.Name = "Stop1"
        Me.Stop2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Stop2.BackColor = System.Drawing.SystemColors.Window
        Me.Stop2.Text = "2"
        Me.Stop2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Stop2.Size = New System.Drawing.Size(33, 17)
        Me.Stop2.Location = New System.Drawing.Point(52, 16)
        Me.Stop2.TabIndex = 8
        Me.Stop2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Stop2.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Stop2.CausesValidation = True
        Me.Stop2.Enabled = True
        Me.Stop2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Stop2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Stop2.Appearance = System.Windows.Forms.Appearance.Normal
        Me.Stop2.TabStop = True
        Me.Stop2.Checked = False
        Me.Stop2.Visible = True
        Me.Stop2.Name = "Stop2"
        Me.Frame7.BackColor = System.Drawing.SystemColors.Window
        Me.Frame7.Text = "&Echo"
        Me.Frame7.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame7.Size = New System.Drawing.Size(91, 41)
        Me.Frame7.Location = New System.Drawing.Point(116, 20)
        Me.Frame7.TabIndex = 9
        Me.Frame7.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame7.Enabled = True
        Me.Frame7.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame7.Visible = True
        Me.Frame7.Name = "Frame7"
        Me.EchoOff.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EchoOff.BackColor = System.Drawing.SystemColors.Window
        Me.EchoOff.Text = "Off"
        Me.EchoOff.ForeColor = System.Drawing.SystemColors.WindowText
        Me.EchoOff.Size = New System.Drawing.Size(39, 21)
        Me.EchoOff.Location = New System.Drawing.Point(46, 16)
        Me.EchoOff.TabIndex = 11
        Me.EchoOff.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EchoOff.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EchoOff.CausesValidation = True
        Me.EchoOff.Enabled = True
        Me.EchoOff.Cursor = System.Windows.Forms.Cursors.Default
        Me.EchoOff.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EchoOff.Appearance = System.Windows.Forms.Appearance.Normal
        Me.EchoOff.TabStop = True
        Me.EchoOff.Checked = False
        Me.EchoOff.Visible = True
        Me.EchoOff.Name = "EchoOff"
        Me.EchoOn.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EchoOn.BackColor = System.Drawing.SystemColors.Window
        Me.EchoOn.Text = "On"
        Me.EchoOn.ForeColor = System.Drawing.SystemColors.WindowText
        Me.EchoOn.Size = New System.Drawing.Size(39, 13)
        Me.EchoOn.Location = New System.Drawing.Point(6, 20)
        Me.EchoOn.TabIndex = 10
        Me.EchoOn.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EchoOn.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EchoOn.CausesValidation = True
        Me.EchoOn.Enabled = True
        Me.EchoOn.Cursor = System.Windows.Forms.Cursors.Default
        Me.EchoOn.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EchoOn.Appearance = System.Windows.Forms.Appearance.Normal
        Me.EchoOn.TabStop = True
        Me.EchoOn.Checked = False
        Me.EchoOn.Visible = True
        Me.EchoOn.Name = "EchoOn"
        Me.Frame4.BackColor = System.Drawing.SystemColors.Window
        Me.Frame4.Text = "&Parity"
        Me.Frame4.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame4.Size = New System.Drawing.Size(85, 105)
        Me.Frame4.Location = New System.Drawing.Point(16, 136)
        Me.Frame4.TabIndex = 12
        Me.Frame4.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame4.Enabled = True
        Me.Frame4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame4.Visible = True
        Me.Frame4.Name = "Frame4"
        Me.NoParity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NoParity.BackColor = System.Drawing.SystemColors.Window
        Me.NoParity.Text = "None"
        Me.NoParity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.NoParity.Size = New System.Drawing.Size(57, 17)
        Me.NoParity.Location = New System.Drawing.Point(8, 20)
        Me.NoParity.TabIndex = 13
        Me.NoParity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoParity.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NoParity.CausesValidation = True
        Me.NoParity.Enabled = True
        Me.NoParity.Cursor = System.Windows.Forms.Cursors.Default
        Me.NoParity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NoParity.Appearance = System.Windows.Forms.Appearance.Normal
        Me.NoParity.TabStop = True
        Me.NoParity.Checked = False
        Me.NoParity.Visible = True
        Me.NoParity.Name = "NoParity"
        Me.OddParity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OddParity.BackColor = System.Drawing.SystemColors.Window
        Me.OddParity.Text = "Odd"
        Me.OddParity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OddParity.Size = New System.Drawing.Size(49, 17)
        Me.OddParity.Location = New System.Drawing.Point(8, 40)
        Me.OddParity.TabIndex = 14
        Me.OddParity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OddParity.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.OddParity.CausesValidation = True
        Me.OddParity.Enabled = True
        Me.OddParity.Cursor = System.Windows.Forms.Cursors.Default
        Me.OddParity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.OddParity.Appearance = System.Windows.Forms.Appearance.Normal
        Me.OddParity.TabStop = True
        Me.OddParity.Checked = False
        Me.OddParity.Visible = True
        Me.OddParity.Name = "OddParity"
        Me.EvenParity.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EvenParity.BackColor = System.Drawing.SystemColors.Window
        Me.EvenParity.Text = "Even"
        Me.EvenParity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.EvenParity.Size = New System.Drawing.Size(57, 17)
        Me.EvenParity.Location = New System.Drawing.Point(8, 60)
        Me.EvenParity.TabIndex = 15
        Me.EvenParity.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EvenParity.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.EvenParity.CausesValidation = True
        Me.EvenParity.Enabled = True
        Me.EvenParity.Cursor = System.Windows.Forms.Cursors.Default
        Me.EvenParity.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.EvenParity.Appearance = System.Windows.Forms.Appearance.Normal
        Me.EvenParity.TabStop = True
        Me.EvenParity.Checked = False
        Me.EvenParity.Visible = True
        Me.EvenParity.Name = "EvenParity"
        Me.Frame6.BackColor = System.Drawing.SystemColors.Window
        Me.Frame6.Text = "&Com Port"
        Me.Frame6.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame6.Size = New System.Drawing.Size(89, 105)
        Me.Frame6.Location = New System.Drawing.Point(116, 136)
        Me.Frame6.TabIndex = 16
        Me.Frame6.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame6.Enabled = True
        Me.Frame6.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame6.Visible = True
        Me.Frame6.Name = "Frame6"
        Me.lstCommPort.Size = New System.Drawing.Size(77, 72)
        Me.lstCommPort.Location = New System.Drawing.Point(6, 20)
        Me.lstCommPort.TabIndex = 22
        Me.lstCommPort.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstCommPort.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lstCommPort.BackColor = System.Drawing.SystemColors.Window
        Me.lstCommPort.CausesValidation = True
        Me.lstCommPort.Enabled = True
        Me.lstCommPort.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstCommPort.IntegralHeight = True
        Me.lstCommPort.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstCommPort.SelectionMode = System.Windows.Forms.SelectionMode.One
        Me.lstCommPort.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstCommPort.Sorted = False
        Me.lstCommPort.TabStop = True
        Me.lstCommPort.Visible = True
        Me.lstCommPort.MultiColumn = False
        Me.lstCommPort.Name = "lstCommPort"
        Me.Frame5.BackColor = System.Drawing.SystemColors.Window
        Me.Frame5.Text = "&Flow Control"
        Me.Frame5.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Frame5.Size = New System.Drawing.Size(97, 105)
        Me.Frame5.Location = New System.Drawing.Point(220, 136)
        Me.Frame5.TabIndex = 17
        Me.Frame5.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame5.Enabled = True
        Me.Frame5.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame5.Visible = True
        Me.Frame5.Name = "Frame5"
        Me.NoFlow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NoFlow.BackColor = System.Drawing.SystemColors.Window
        Me.NoFlow.Text = "None"
        Me.NoFlow.ForeColor = System.Drawing.SystemColors.WindowText
        Me.NoFlow.Size = New System.Drawing.Size(57, 17)
        Me.NoFlow.Location = New System.Drawing.Point(8, 20)
        Me.NoFlow.TabIndex = 20
        Me.NoFlow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NoFlow.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.NoFlow.CausesValidation = True
        Me.NoFlow.Enabled = True
        Me.NoFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.NoFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.NoFlow.Appearance = System.Windows.Forms.Appearance.Normal
        Me.NoFlow.TabStop = True
        Me.NoFlow.Checked = False
        Me.NoFlow.Visible = True
        Me.NoFlow.Name = "NoFlow"
        Me.XonFlow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.XonFlow.BackColor = System.Drawing.SystemColors.Window
        Me.XonFlow.Text = "Xon/Xoff"
        Me.XonFlow.ForeColor = System.Drawing.SystemColors.WindowText
        Me.XonFlow.Size = New System.Drawing.Size(73, 17)
        Me.XonFlow.Location = New System.Drawing.Point(8, 40)
        Me.XonFlow.TabIndex = 18
        Me.XonFlow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.XonFlow.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.XonFlow.CausesValidation = True
        Me.XonFlow.Enabled = True
        Me.XonFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.XonFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.XonFlow.Appearance = System.Windows.Forms.Appearance.Normal
        Me.XonFlow.TabStop = True
        Me.XonFlow.Checked = False
        Me.XonFlow.Visible = True
        Me.XonFlow.Name = "XonFlow"
        Me.RTSFlow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.RTSFlow.BackColor = System.Drawing.SystemColors.Window
        Me.RTSFlow.Text = "RTS"
        Me.RTSFlow.ForeColor = System.Drawing.SystemColors.WindowText
        Me.RTSFlow.Size = New System.Drawing.Size(49, 17)
        Me.RTSFlow.Location = New System.Drawing.Point(8, 60)
        Me.RTSFlow.TabIndex = 19
        Me.RTSFlow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RTSFlow.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.RTSFlow.CausesValidation = True
        Me.RTSFlow.Enabled = True
        Me.RTSFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.RTSFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.RTSFlow.Appearance = System.Windows.Forms.Appearance.Normal
        Me.RTSFlow.TabStop = True
        Me.RTSFlow.Checked = False
        Me.RTSFlow.Visible = True
        Me.RTSFlow.Name = "RTSFlow"
        Me.BothFlow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BothFlow.BackColor = System.Drawing.SystemColors.Window
        Me.BothFlow.Text = "Xon/RTS"
        Me.BothFlow.ForeColor = System.Drawing.SystemColors.WindowText
        Me.BothFlow.Size = New System.Drawing.Size(77, 17)
        Me.BothFlow.Location = New System.Drawing.Point(8, 80)
        Me.BothFlow.TabIndex = 21
        Me.BothFlow.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BothFlow.CheckAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.BothFlow.CausesValidation = True
        Me.BothFlow.Enabled = True
        Me.BothFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.BothFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BothFlow.Appearance = System.Windows.Forms.Appearance.Normal
        Me.BothFlow.TabStop = True
        Me.BothFlow.Checked = False
        Me.BothFlow.Visible = True
        Me.BothFlow.Name = "BothFlow"
        Me.Controls.Add(Frame1)
        Me.Controls.Add(OKButton)
        Me.Controls.Add(CancelButton_Renamed)
        Me.Controls.Add(Frame2)
        Me.Controls.Add(Frame3)
        Me.Controls.Add(Frame7)
        Me.Controls.Add(Frame4)
        Me.Controls.Add(Frame6)
        Me.Controls.Add(Frame5)
        Me.Frame1.Controls.Add(lstRate)
        Me.Frame2.Controls.Add(Data7)
        Me.Frame2.Controls.Add(Data8)
        Me.Frame3.Controls.Add(Stop1)
        Me.Frame3.Controls.Add(Stop2)
        Me.Frame7.Controls.Add(EchoOff)
        Me.Frame7.Controls.Add(EchoOn)
        Me.Frame4.Controls.Add(NoParity)
        Me.Frame4.Controls.Add(OddParity)
        Me.Frame4.Controls.Add(EvenParity)
        Me.Frame6.Controls.Add(lstCommPort)
        Me.Frame5.Controls.Add(NoFlow)
        Me.Frame5.Controls.Add(XonFlow)
        Me.Frame5.Controls.Add(RTSFlow)
        Me.Frame5.Controls.Add(BothFlow)
    End Sub
#End Region 

    '***********  Communication Settings Configuration Form

    Private NewData As String
    Private NewStop As String
    Private NewParity As String
    Private NewShake As Short

    Private Sub BothFlow_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles BothFlow.CheckedChanged
        If eventSender.Checked Then
            Dim NewFlow As Object
            NewFlow = MSCommLib.HandshakeConstants.comRTSXOnXOff
        End If
    End Sub

    '
    '--- Even parity option button
    '
    Private Sub EvenParity_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles EvenParity.CheckedChanged
        If eventSender.Checked Then
            NewParity = "E"
        End If
    End Sub

    '
    '--- No handshaking option button
    '
    Private Sub NoFlow_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles NoFlow.CheckedChanged
        If eventSender.Checked Then
            NewShake = MSCommLib.HandshakeConstants.comNone
        End If
    End Sub

    '
    '--- No parity option button
    '
    Private Sub NoParity_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles NoParity.CheckedChanged
        If eventSender.Checked Then
            NewParity = "N"
        End If
    End Sub

    '
    '--- Odd parity option button
    '
    Private Sub OddParity_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OddParity.CheckedChanged
        If eventSender.Checked Then
            NewParity = "O"
        End If
    End Sub


    '--- Cancel button actions
    '
    Private Sub CancelButton_Renamed_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles CancelButton_Renamed.Click
        Me.Close()
    End Sub

    '
    '--- Initialize and display configuration form
    '
    Private Sub frmConfigScrn_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
        Dim SBits As String
        Dim ThirdComma As Object
        Dim DBits As String
        Dim SecondComma As Object
        Dim Parity As String
        Dim FirstComma As Object
        Dim Port As Object
        Dim I As Short
        Dim Baud As String
        For I = 1 To 16
            lstCommPort.Items.Add(VB6.Format(I))
        Next I
        lstRate.Items.Add("300")
        lstRate.Items.Add("1200")
        lstRate.Items.Add("2400")
        lstRate.Items.Add("4800")
        lstRate.Items.Add("9600")
        lstRate.Items.Add("19200")
        lstRate.Items.Add("38400")
        lstRate.Items.Add("57600")
        lstRate.Items.Add("115200")

        '--- Get current port
        Port = frmTerm.DefInstance.NETComm1.CommPort
        lstCommPort.SelectedIndex = Port - 1

        '--- Get current baud
        FirstComma = InStr(frmTerm.DefInstance.NETComm1.get_Settings(), ",")
        Baud = VB.Left(frmTerm.DefInstance.NETComm1.get_Settings(), FirstComma - 1)

        Select Case Val(Baud) 'select baud
            Case 300 'set active baud
                lstRate.SelectedIndex = 0
            Case 1200
                lstRate.SelectedIndex = 1
            Case 2400
                lstRate.SelectedIndex = 2
            Case 4800
                lstRate.SelectedIndex = 3
            Case 9600
                lstRate.SelectedIndex = 4
            Case 19200
                lstRate.SelectedIndex = 5
            Case 38400
                lstRate.SelectedIndex = 6
            Case 57600
                lstRate.SelectedIndex = 7
            Case 115200
                lstRate.SelectedIndex = 8
            Case Else
                lstRate.SelectedIndex = 4
        End Select

        '--- Get current parity
        Parity = Mid(frmTerm.DefInstance.NETComm1.get_Settings(), FirstComma + 1, 1)

        Select Case UCase(Parity) 'select parity
            Case "N" 'set active parity
                Me.NoParity.Checked = True 'option button
            Case "E"
                Me.EvenParity.Checked = True
            Case "O"
                Me.OddParity.Checked = True
        End Select

        '--- Get data bits
        SecondComma = FirstComma + 2
        DBits = Mid(frmTerm.DefInstance.NETComm1.get_Settings(), SecondComma + 1, 1)
        Select Case Val(DBits) 'select data bits
            Case 7 'set active choice
                Me.Data7.Checked = True 'option button
            Case 8
                Me.Data8.Checked = True
        End Select

        '--- Get stop bits
        ThirdComma = SecondComma + 2
        SBits = Mid(frmTerm.DefInstance.NETComm1.get_Settings(), ThirdComma + 1, 1)
        Select Case Val(SBits) 'select stop bits
            Case 1 'set active choice
                Me.Stop1.Checked = True 'option button
            Case 2
                Me.Stop2.Checked = True
        End Select

        Select Case frmTerm.DefInstance.NETComm1.Handshaking
            Case 0 'set active choice
                Me.NoFlow.Checked = True 'option button
            Case 1
                Me.XonFlow.Checked = True
            Case 2
                Me.RTSFlow.Checked = True
            Case 3
                Me.BothFlow.Checked = True
        End Select

        If Echo Then
            Me.EchoOn.Checked = True
        Else
            Me.EchoOff.Checked = True
        End If
    End Sub

    '
    '--- Ok button actions
    '
    Private Sub OkButton_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles OKButton.Click
        Dim OldPort As Short
        Dim PortOpen As Boolean
        On Error Resume Next

        OldPort = frmTerm.DefInstance.NETComm1.CommPort
        If lstCommPort.SelectedIndex + 1 <> OldPort Then
            If frmTerm.DefInstance.NETComm1.PortOpen Then frmTerm.DefInstance.NETComm1.PortOpen = False
            frmTerm.DefInstance.NETComm1.CommPort = lstCommPort.SelectedIndex + 1 'set new port number
            If Err.Number = 0 Then
                If PortOpen = True Then
                    frmTerm.DefInstance.NETComm1.PortOpen = True
                    If Err.Number <> 0 Then
                        MsgBox("Unable to open new port")
                        frmTerm.DefInstance.NETComm1.CommPort = OldPort
                    End If
                End If
            End If
            frmTerm.DefInstance.MOpen.Checked = frmTerm.DefInstance.NETComm1.PortOpen
            frmTerm.DefInstance.MSendText.Enabled = frmTerm.DefInstance.NETComm1.PortOpen
        End If

        frmTerm.DefInstance.NETComm1.set_Settings(lstRate.Text & "," & NewParity & "," & NewData & "," & NewStop)

        frmTerm.DefInstance.NETComm1.Handshaking = NewShake

        Me.Close() 'remove configuration form
    End Sub

    '
    '--- RTS handshaking option button
    '
    Private Sub RTSFlow_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles RTSFlow.CheckedChanged
        If eventSender.Checked Then
            NewShake = MSCommLib.HandshakeConstants.comRTS
        End If
    End Sub

    '
    '--- 1 stop bit option button
    '
    Private Sub Stop1_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Stop1.CheckedChanged
        If eventSender.Checked Then
            NewStop = "1"
        End If
    End Sub

    '
    '--- 2 stop bits option button
    '
    Private Sub Stop2_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Stop2.CheckedChanged
        If eventSender.Checked Then
            NewStop = "2"
        End If
    End Sub

    '
    '--- XON handshaking option button
    '
    Private Sub XonFlow_CheckedChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles XonFlow.CheckedChanged
        If eventSender.Checked Then
            NewShake = MSCommLib.HandshakeConstants.comXOnXoff
        End If
    End Sub
End Class