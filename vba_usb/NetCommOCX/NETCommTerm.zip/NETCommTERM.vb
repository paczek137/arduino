Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Friend Class frmTerm
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents NETComm1 As AxNETCommOCX.AxNETComm
	Public WithEvents Timer1 As System.Windows.Forms.Timer
	Public WithEvents StatusTimer As System.Windows.Forms.Timer
	Public WithEvents _LED2_5 As System.Windows.Forms.PictureBox
	Public WithEvents _LED2_4 As System.Windows.Forms.PictureBox
	Public WithEvents _LED2_3 As System.Windows.Forms.PictureBox
	Public WithEvents _LED2_2 As System.Windows.Forms.PictureBox
	Public WithEvents _LED2_1 As System.Windows.Forms.PictureBox
	Public WithEvents _LED2_0 As System.Windows.Forms.PictureBox
	Public WithEvents Status As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_5 As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_4 As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_3 As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_2 As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_1 As System.Windows.Forms.Label
	Public WithEvents _LEDLabel_0 As System.Windows.Forms.Label
	Public WithEvents StatusArea As System.Windows.Forms.Panel
	Public WithEvents Term As System.Windows.Forms.TextBox
	Public WithEvents OpenLog As AxMSComDlg.AxCommonDialog
	Public WithEvents Line2 As System.Windows.Forms.Label
	Public WithEvents Line1 As System.Windows.Forms.Label
	Public WithEvents LED2 As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
	Public WithEvents LEDLabel As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
	Public WithEvents MOpenLog As System.Windows.Forms.MenuItem
	Public WithEvents MCloseLog As System.Windows.Forms.MenuItem
	Public WithEvents M3 As System.Windows.Forms.MenuItem
	Public WithEvents MSendText As System.Windows.Forms.MenuItem
	Public WithEvents Bar2 As System.Windows.Forms.MenuItem
	Public WithEvents MFileExit As System.Windows.Forms.MenuItem
	Public WithEvents MFile As System.Windows.Forms.MenuItem
	Public WithEvents MOpen As System.Windows.Forms.MenuItem
	Public WithEvents MSettings As System.Windows.Forms.MenuItem
	Public WithEvents MBar1 As System.Windows.Forms.MenuItem
	Public WithEvents MDial As System.Windows.Forms.MenuItem
	Public WithEvents MHangup As System.Windows.Forms.MenuItem
	Public WithEvents MPort As System.Windows.Forms.MenuItem
	Public WithEvents MInputLen As System.Windows.Forms.MenuItem
	Public WithEvents MRThreshold As System.Windows.Forms.MenuItem
	Public WithEvents MSThreshold As System.Windows.Forms.MenuItem
	Public WithEvents MParRep As System.Windows.Forms.MenuItem
	Public WithEvents MDTREnable As System.Windows.Forms.MenuItem
	Public WithEvents Bar3 As System.Windows.Forms.MenuItem
	Public WithEvents MHCD As System.Windows.Forms.MenuItem
	Public WithEvents MHCTS As System.Windows.Forms.MenuItem
	Public WithEvents MHDSR As System.Windows.Forms.MenuItem
	Public WithEvents MProp As System.Windows.Forms.MenuItem
	Public WithEvents About As System.Windows.Forms.MenuItem
	Public MainMenu1 As System.Windows.Forms.MainMenu
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
		Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmTerm))
		Me.components = New System.ComponentModel.Container()
		Me.ToolTip1 = New System.Windows.Forms.ToolTip(components)
		Me.ToolTip1.Active = True
		Me.NETComm1 = New AxNETCommOCX.AxNETComm
		Me.Timer1 = New System.Windows.Forms.Timer(components)
		Me.StatusTimer = New System.Windows.Forms.Timer(components)
		Me.StatusArea = New System.Windows.Forms.Panel
		Me._LED2_5 = New System.Windows.Forms.PictureBox
		Me._LED2_4 = New System.Windows.Forms.PictureBox
		Me._LED2_3 = New System.Windows.Forms.PictureBox
		Me._LED2_2 = New System.Windows.Forms.PictureBox
		Me._LED2_1 = New System.Windows.Forms.PictureBox
		Me._LED2_0 = New System.Windows.Forms.PictureBox
		Me.Status = New System.Windows.Forms.Label
		Me._LEDLabel_5 = New System.Windows.Forms.Label
		Me._LEDLabel_4 = New System.Windows.Forms.Label
		Me._LEDLabel_3 = New System.Windows.Forms.Label
		Me._LEDLabel_2 = New System.Windows.Forms.Label
		Me._LEDLabel_1 = New System.Windows.Forms.Label
		Me._LEDLabel_0 = New System.Windows.Forms.Label
		Me.Term = New System.Windows.Forms.TextBox
		Me.OpenLog = New AxMSComDlg.AxCommonDialog
		Me.Line2 = New System.Windows.Forms.Label
		Me.Line1 = New System.Windows.Forms.Label
		Me.LED2 = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(components)
		Me.LEDLabel = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
		Me.MainMenu1 = New System.Windows.Forms.MainMenu
		Me.MFile = New System.Windows.Forms.MenuItem
		Me.MOpenLog = New System.Windows.Forms.MenuItem
		Me.MCloseLog = New System.Windows.Forms.MenuItem
		Me.M3 = New System.Windows.Forms.MenuItem
		Me.MSendText = New System.Windows.Forms.MenuItem
		Me.Bar2 = New System.Windows.Forms.MenuItem
		Me.MFileExit = New System.Windows.Forms.MenuItem
		Me.MPort = New System.Windows.Forms.MenuItem
		Me.MOpen = New System.Windows.Forms.MenuItem
		Me.MSettings = New System.Windows.Forms.MenuItem
		Me.MBar1 = New System.Windows.Forms.MenuItem
		Me.MDial = New System.Windows.Forms.MenuItem
		Me.MHangup = New System.Windows.Forms.MenuItem
		Me.MProp = New System.Windows.Forms.MenuItem
		Me.MInputLen = New System.Windows.Forms.MenuItem
		Me.MRThreshold = New System.Windows.Forms.MenuItem
		Me.MSThreshold = New System.Windows.Forms.MenuItem
		Me.MParRep = New System.Windows.Forms.MenuItem
		Me.MDTREnable = New System.Windows.Forms.MenuItem
		Me.Bar3 = New System.Windows.Forms.MenuItem
		Me.MHCD = New System.Windows.Forms.MenuItem
		Me.MHCTS = New System.Windows.Forms.MenuItem
		Me.MHDSR = New System.Windows.Forms.MenuItem
		Me.About = New System.Windows.Forms.MenuItem
		CType(Me.NETComm1, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.OpenLog, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.LED2, System.ComponentModel.ISupportInitialize).BeginInit()
		CType(Me.LEDLabel, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
		Me.BackColor = System.Drawing.Color.FromARGB(192, 192, 192)
		Me.Text = "NETComm Terminal "
		Me.ClientSize = New System.Drawing.Size(486, 217)
		Me.Location = New System.Drawing.Point(82, 152)
		Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.ForeColor = System.Drawing.Color.Black
		Me.Icon = CType(resources.GetObject("frmTerm.Icon"), System.Drawing.Icon)
		Me.AutoScaleBaseSize = New System.Drawing.Size(6, 13)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Sizable
		Me.ControlBox = True
		Me.Enabled = True
		Me.KeyPreview = False
		Me.MaximizeBox = True
		Me.MinimizeBox = True
		Me.Cursor = System.Windows.Forms.Cursors.Default
		Me.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.ShowInTaskbar = True
		Me.HelpButton = False
		Me.WindowState = System.Windows.Forms.FormWindowState.Normal
		Me.Name = "frmTerm"
		NETComm1.OcxState = CType(resources.GetObject("NETComm1.OcxState"), System.Windows.Forms.AxHost.State)
		Me.NETComm1.Location = New System.Drawing.Point(222, 90)
		Me.NETComm1.Name = "NETComm1"
		Me.Timer1.Enabled = False
		Me.Timer1.Interval = 1
		Me.StatusTimer.Interval = 150
		Me.StatusTimer.Enabled = True
		Me.StatusArea.Dock = System.Windows.Forms.DockStyle.Bottom
		Me.StatusArea.Size = New System.Drawing.Size(486, 38)
		Me.StatusArea.Location = New System.Drawing.Point(0, 179)
		Me.StatusArea.TabIndex = 0
		Me.StatusArea.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.StatusArea.BackColor = System.Drawing.SystemColors.Control
		Me.StatusArea.CausesValidation = True
		Me.StatusArea.Enabled = True
		Me.StatusArea.ForeColor = System.Drawing.SystemColors.ControlText
		Me.StatusArea.Cursor = System.Windows.Forms.Cursors.Default
		Me.StatusArea.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.StatusArea.TabStop = True
		Me.StatusArea.Visible = True
		Me.StatusArea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.StatusArea.Name = "StatusArea"
		Me._LED2_5.BackColor = System.Drawing.Color.Black
		Me._LED2_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_5.Size = New System.Drawing.Size(17, 10)
		Me._LED2_5.Location = New System.Drawing.Point(147, 9)
		Me._LED2_5.TabIndex = 8
		Me._LED2_5.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_5.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_5.CausesValidation = True
		Me._LED2_5.Enabled = True
		Me._LED2_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_5.TabStop = True
		Me._LED2_5.Visible = True
		Me._LED2_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_5.Name = "_LED2_5"
		Me._LED2_4.BackColor = System.Drawing.Color.Black
		Me._LED2_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_4.Size = New System.Drawing.Size(17, 10)
		Me._LED2_4.Location = New System.Drawing.Point(122, 9)
		Me._LED2_4.TabIndex = 9
		Me._LED2_4.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_4.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_4.CausesValidation = True
		Me._LED2_4.Enabled = True
		Me._LED2_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_4.TabStop = True
		Me._LED2_4.Visible = True
		Me._LED2_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_4.Name = "_LED2_4"
		Me._LED2_3.BackColor = System.Drawing.Color.Black
		Me._LED2_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_3.Size = New System.Drawing.Size(17, 10)
		Me._LED2_3.Location = New System.Drawing.Point(95, 9)
		Me._LED2_3.TabIndex = 10
		Me._LED2_3.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_3.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_3.CausesValidation = True
		Me._LED2_3.Enabled = True
		Me._LED2_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_3.TabStop = True
		Me._LED2_3.Visible = True
		Me._LED2_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_3.Name = "_LED2_3"
		Me._LED2_2.BackColor = System.Drawing.Color.Black
		Me._LED2_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_2.Size = New System.Drawing.Size(17, 10)
		Me._LED2_2.Location = New System.Drawing.Point(68, 9)
		Me._LED2_2.TabIndex = 11
		Me._LED2_2.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_2.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_2.CausesValidation = True
		Me._LED2_2.Enabled = True
		Me._LED2_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_2.TabStop = True
		Me._LED2_2.Visible = True
		Me._LED2_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_2.Name = "_LED2_2"
		Me._LED2_1.BackColor = System.Drawing.Color.Black
		Me._LED2_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_1.Size = New System.Drawing.Size(17, 10)
		Me._LED2_1.Location = New System.Drawing.Point(42, 9)
		Me._LED2_1.TabIndex = 12
		Me._LED2_1.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_1.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_1.CausesValidation = True
		Me._LED2_1.Enabled = True
		Me._LED2_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_1.TabStop = True
		Me._LED2_1.Visible = True
		Me._LED2_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_1.Name = "_LED2_1"
		Me._LED2_0.BackColor = System.Drawing.Color.Black
		Me._LED2_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LED2_0.Size = New System.Drawing.Size(17, 10)
		Me._LED2_0.Location = New System.Drawing.Point(15, 9)
		Me._LED2_0.TabIndex = 13
		Me._LED2_0.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LED2_0.Dock = System.Windows.Forms.DockStyle.None
		Me._LED2_0.CausesValidation = True
		Me._LED2_0.Enabled = True
		Me._LED2_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._LED2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LED2_0.TabStop = True
		Me._LED2_0.Visible = True
		Me._LED2_0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Normal
		Me._LED2_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me._LED2_0.Name = "_LED2_0"
		Me.Status.Size = New System.Drawing.Size(289, 17)
		Me.Status.Location = New System.Drawing.Point(184, 8)
		Me.Status.TabIndex = 14
		Me.Status.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Status.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me.Status.BackColor = System.Drawing.SystemColors.Control
		Me.Status.Enabled = True
		Me.Status.ForeColor = System.Drawing.SystemColors.ControlText
		Me.Status.Cursor = System.Windows.Forms.Cursors.Default
		Me.Status.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Status.UseMnemonic = True
		Me.Status.Visible = True
		Me.Status.AutoSize = False
		Me.Status.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.Status.Name = "Status"
		Me._LEDLabel_5.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_5.Text = "TR"
		Me._LEDLabel_5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_5.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_5.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_5.Location = New System.Drawing.Point(149, 17)
		Me._LEDLabel_5.TabIndex = 1
		Me._LEDLabel_5.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_5.Enabled = True
		Me._LEDLabel_5.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_5.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_5.UseMnemonic = True
		Me._LEDLabel_5.Visible = True
		Me._LEDLabel_5.AutoSize = False
		Me._LEDLabel_5.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_5.Name = "_LEDLabel_5"
		Me._LEDLabel_4.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_4.Text = "SD"
		Me._LEDLabel_4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_4.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_4.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_4.Location = New System.Drawing.Point(123, 17)
		Me._LEDLabel_4.TabIndex = 2
		Me._LEDLabel_4.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_4.Enabled = True
		Me._LEDLabel_4.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_4.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_4.UseMnemonic = True
		Me._LEDLabel_4.Visible = True
		Me._LEDLabel_4.AutoSize = False
		Me._LEDLabel_4.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_4.Name = "_LEDLabel_4"
		Me._LEDLabel_3.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_3.Text = "RD"
		Me._LEDLabel_3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_3.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_3.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_3.Location = New System.Drawing.Point(97, 17)
		Me._LEDLabel_3.TabIndex = 3
		Me._LEDLabel_3.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_3.Enabled = True
		Me._LEDLabel_3.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_3.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_3.UseMnemonic = True
		Me._LEDLabel_3.Visible = True
		Me._LEDLabel_3.AutoSize = False
		Me._LEDLabel_3.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_3.Name = "_LEDLabel_3"
		Me._LEDLabel_2.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_2.Text = "OH"
		Me._LEDLabel_2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_2.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_2.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_2.Location = New System.Drawing.Point(69, 17)
		Me._LEDLabel_2.TabIndex = 4
		Me._LEDLabel_2.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_2.Enabled = True
		Me._LEDLabel_2.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_2.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_2.UseMnemonic = True
		Me._LEDLabel_2.Visible = True
		Me._LEDLabel_2.AutoSize = False
		Me._LEDLabel_2.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_2.Name = "_LEDLabel_2"
		Me._LEDLabel_1.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_1.Text = "CD"
		Me._LEDLabel_1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_1.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_1.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_1.Location = New System.Drawing.Point(43, 17)
		Me._LEDLabel_1.TabIndex = 5
		Me._LEDLabel_1.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_1.Enabled = True
		Me._LEDLabel_1.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_1.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_1.UseMnemonic = True
		Me._LEDLabel_1.Visible = True
		Me._LEDLabel_1.AutoSize = False
		Me._LEDLabel_1.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_1.Name = "_LEDLabel_1"
		Me._LEDLabel_0.BackColor = System.Drawing.SystemColors.Menu
		Me._LEDLabel_0.Text = "HS"
		Me._LEDLabel_0.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me._LEDLabel_0.ForeColor = System.Drawing.SystemColors.WindowText
		Me._LEDLabel_0.Size = New System.Drawing.Size(20, 12)
		Me._LEDLabel_0.Location = New System.Drawing.Point(17, 17)
		Me._LEDLabel_0.TabIndex = 6
		Me._LEDLabel_0.TextAlign = System.Drawing.ContentAlignment.TopLeft
		Me._LEDLabel_0.Enabled = True
		Me._LEDLabel_0.Cursor = System.Windows.Forms.Cursors.Default
		Me._LEDLabel_0.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me._LEDLabel_0.UseMnemonic = True
		Me._LEDLabel_0.Visible = True
		Me._LEDLabel_0.AutoSize = False
		Me._LEDLabel_0.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me._LEDLabel_0.Name = "_LEDLabel_0"
		Me.Term.AutoSize = False
		Me.Term.Size = New System.Drawing.Size(75, 35)
		Me.Term.Location = New System.Drawing.Point(52, 32)
		Me.Term.MultiLine = True
		Me.Term.ScrollBars = System.Windows.Forms.ScrollBars.Both
		Me.Term.WordWrap = False
		Me.Term.TabIndex = 7
		Me.Term.Font = New System.Drawing.Font("Arial", 8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Term.AcceptsReturn = True
		Me.Term.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
		Me.Term.BackColor = System.Drawing.SystemColors.Window
		Me.Term.CausesValidation = True
		Me.Term.Enabled = True
		Me.Term.ForeColor = System.Drawing.SystemColors.WindowText
		Me.Term.HideSelection = True
		Me.Term.ReadOnly = False
		Me.Term.Maxlength = 0
		Me.Term.Cursor = System.Windows.Forms.Cursors.IBeam
		Me.Term.RightToLeft = System.Windows.Forms.RightToLeft.No
		Me.Term.TabStop = True
		Me.Term.Visible = True
		Me.Term.BorderStyle = System.Windows.Forms.BorderStyle.None
		Me.Term.Name = "Term"
		OpenLog.OcxState = CType(resources.GetObject("OpenLog.OcxState"), System.Windows.Forms.AxHost.State)
		Me.OpenLog.Location = New System.Drawing.Point(0, 60)
		Me.OpenLog.Name = "OpenLog"
		Me.Line2.BackColor = System.Drawing.Color.White
		Me.Line2.Visible = True
		Me.Line2.Location = New System.Drawing.Point(0, 1)
		Me.Line2.Width = 483
		Me.Line2.Height = 1
		Me.Line2.Name = "Line2"
		Me.Line1.BackColor = System.Drawing.SystemColors.WindowText
		Me.Line1.Visible = True
		Me.Line1.Location = New System.Drawing.Point(0, 0)
		Me.Line1.Width = 485
		Me.Line1.Height = 1
		Me.Line1.Name = "Line1"
		Me.MFile.Text = "&File"
		Me.MFile.Checked = False
		Me.MFile.Enabled = True
		Me.MFile.Visible = True
		Me.MFile.MDIList = False
		Me.MOpenLog.Text = "&Open Log File..."
		Me.MOpenLog.Checked = False
		Me.MOpenLog.Enabled = True
		Me.MOpenLog.Visible = True
		Me.MOpenLog.MDIList = False
		Me.MCloseLog.Text = "&Close Log File"
		Me.MCloseLog.Enabled = False
		Me.MCloseLog.Checked = False
		Me.MCloseLog.Visible = True
		Me.MCloseLog.MDIList = False
		Me.M3.Text = "-"
		Me.M3.Checked = False
		Me.M3.Enabled = True
		Me.M3.Visible = True
		Me.M3.MDIList = False
		Me.MSendText.Text = "&Transmit Text File..."
		Me.MSendText.Enabled = False
		Me.MSendText.Checked = False
		Me.MSendText.Visible = True
		Me.MSendText.MDIList = False
		Me.Bar2.Text = "-"
		Me.Bar2.Checked = False
		Me.Bar2.Enabled = True
		Me.Bar2.Visible = True
		Me.Bar2.MDIList = False
		Me.MFileExit.Text = "E&xit"
		Me.MFileExit.Checked = False
		Me.MFileExit.Enabled = True
		Me.MFileExit.Visible = True
		Me.MFileExit.MDIList = False
		Me.MPort.Text = "&CommPort"
		Me.MPort.Checked = False
		Me.MPort.Enabled = True
		Me.MPort.Visible = True
		Me.MPort.MDIList = False
		Me.MOpen.Text = "Port &Open"
		Me.MOpen.Checked = False
		Me.MOpen.Enabled = True
		Me.MOpen.Visible = True
		Me.MOpen.MDIList = False
		Me.MSettings.Text = "&Settings..."
		Me.MSettings.Checked = False
		Me.MSettings.Enabled = True
		Me.MSettings.Visible = True
		Me.MSettings.MDIList = False
		Me.MBar1.Text = "-"
		Me.MBar1.Checked = False
		Me.MBar1.Enabled = True
		Me.MBar1.Visible = True
		Me.MBar1.MDIList = False
		Me.MDial.Text = "&Dial Phone Number..."
		Me.MDial.Checked = False
		Me.MDial.Enabled = True
		Me.MDial.Visible = True
		Me.MDial.MDIList = False
		Me.MHangup.Text = "&Hang Up Modem"
		Me.MHangup.Enabled = False
		Me.MHangup.Checked = False
		Me.MHangup.Visible = True
		Me.MHangup.MDIList = False
		Me.MProp.Text = "&Properties"
		Me.MProp.Checked = False
		Me.MProp.Enabled = True
		Me.MProp.Visible = True
		Me.MProp.MDIList = False
		Me.MInputLen.Text = "&InputLen..."
		Me.MInputLen.Checked = False
		Me.MInputLen.Enabled = True
		Me.MInputLen.Visible = True
		Me.MInputLen.MDIList = False
		Me.MRThreshold.Text = "&RThreshold..."
		Me.MRThreshold.Checked = False
		Me.MRThreshold.Enabled = True
		Me.MRThreshold.Visible = True
		Me.MRThreshold.MDIList = False
		Me.MSThreshold.Text = "&SThreshold..."
		Me.MSThreshold.Checked = False
		Me.MSThreshold.Enabled = True
		Me.MSThreshold.Visible = True
		Me.MSThreshold.MDIList = False
		Me.MParRep.Text = "P&arityReplace..."
		Me.MParRep.Checked = False
		Me.MParRep.Enabled = True
		Me.MParRep.Visible = True
		Me.MParRep.MDIList = False
		Me.MDTREnable.Text = "&DTREnable"
		Me.MDTREnable.Checked = True
		Me.MDTREnable.Enabled = True
		Me.MDTREnable.Visible = True
		Me.MDTREnable.MDIList = False
		Me.Bar3.Text = "-"
		Me.Bar3.Checked = False
		Me.Bar3.Enabled = True
		Me.Bar3.Visible = True
		Me.Bar3.MDIList = False
		Me.MHCD.Text = "&CDHolding..."
		Me.MHCD.Checked = False
		Me.MHCD.Enabled = True
		Me.MHCD.Visible = True
		Me.MHCD.MDIList = False
		Me.MHCTS.Text = "CTSH&olding..."
		Me.MHCTS.Checked = False
		Me.MHCTS.Enabled = True
		Me.MHCTS.Visible = True
		Me.MHCTS.MDIList = False
		Me.MHDSR.Text = "DSRHo&lding..."
		Me.MHDSR.Checked = False
		Me.MHDSR.Enabled = True
		Me.MHDSR.Visible = True
		Me.MHDSR.MDIList = False
		Me.About.Text = "&About"
		Me.About.Checked = False
		Me.About.Enabled = True
		Me.About.Visible = True
		Me.About.MDIList = False
		Me.Controls.Add(NETComm1)
		Me.Controls.Add(StatusArea)
		Me.Controls.Add(Term)
		Me.Controls.Add(OpenLog)
		Me.Controls.Add(Line2)
		Me.Controls.Add(Line1)
		Me.StatusArea.Controls.Add(_LED2_5)
		Me.StatusArea.Controls.Add(_LED2_4)
		Me.StatusArea.Controls.Add(_LED2_3)
		Me.StatusArea.Controls.Add(_LED2_2)
		Me.StatusArea.Controls.Add(_LED2_1)
		Me.StatusArea.Controls.Add(_LED2_0)
		Me.StatusArea.Controls.Add(Status)
		Me.StatusArea.Controls.Add(_LEDLabel_5)
		Me.StatusArea.Controls.Add(_LEDLabel_4)
		Me.StatusArea.Controls.Add(_LEDLabel_3)
		Me.StatusArea.Controls.Add(_LEDLabel_2)
		Me.StatusArea.Controls.Add(_LEDLabel_1)
		Me.StatusArea.Controls.Add(_LEDLabel_0)
		Me.LED2.SetIndex(_LED2_5, CType(5, Short))
		Me.LED2.SetIndex(_LED2_4, CType(4, Short))
		Me.LED2.SetIndex(_LED2_3, CType(3, Short))
		Me.LED2.SetIndex(_LED2_2, CType(2, Short))
		Me.LED2.SetIndex(_LED2_1, CType(1, Short))
		Me.LED2.SetIndex(_LED2_0, CType(0, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_5, CType(5, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_4, CType(4, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_3, CType(3, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_2, CType(2, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_1, CType(1, Short))
		Me.LEDLabel.SetIndex(_LEDLabel_0, CType(0, Short))
		CType(Me.LEDLabel, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.LED2, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.OpenLog, System.ComponentModel.ISupportInitialize).EndInit()
		CType(Me.NETComm1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.MFile.Index = 0
		Me.MPort.Index = 1
		Me.MProp.Index = 2
		Me.About.Index = 3
		MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem(){Me.MFile, Me.MPort, Me.MProp, Me.About})
		Me.MOpenLog.Index = 0
		Me.MCloseLog.Index = 1
		Me.M3.Index = 2
		Me.MSendText.Index = 3
		Me.Bar2.Index = 4
		Me.MFileExit.Index = 5
		MFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem(){Me.MOpenLog, Me.MCloseLog, Me.M3, Me.MSendText, Me.Bar2, Me.MFileExit})
		Me.MOpen.Index = 0
		Me.MSettings.Index = 1
		Me.MBar1.Index = 2
		Me.MDial.Index = 3
		Me.MHangup.Index = 4
		MPort.MenuItems.AddRange(New System.Windows.Forms.MenuItem(){Me.MOpen, Me.MSettings, Me.MBar1, Me.MDial, Me.MHangup})
		Me.MInputLen.Index = 0
		Me.MRThreshold.Index = 1
		Me.MSThreshold.Index = 2
		Me.MParRep.Index = 3
		Me.MDTREnable.Index = 4
		Me.Bar3.Index = 5
		Me.MHCD.Index = 6
		Me.MHCTS.Index = 7
		Me.MHDSR.Index = 8
		MProp.MenuItems.AddRange(New System.Windows.Forms.MenuItem(){Me.MInputLen, Me.MRThreshold, Me.MSThreshold, Me.MParRep, Me.MDTREnable, Me.Bar3, Me.MHCD, Me.MHCTS, Me.MHDSR})
		Me.Menu = MainMenu1
	End Sub
#End Region 
#Region "Upgrade Support "
	Private Shared m_vb6FormDefInstance As frmTerm
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmTerm
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmTerm()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	
	Private hLogFile As Short 'Handle of open log file
	
	Public Sub About_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles About.Popup
		About_Click(eventSender, eventArgs)
	End Sub
	Public Sub About_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles About.Click
		MsgBox("This program demonstrates use of the MSComm32.ocx control to create a simple terminal program." & vbLf & "Copyright Mabry Software, 2001")
	End Sub
	
	Private Sub CommOutput(ByRef OutputString As String)
		On Error Resume Next
		If NETComm1.PortOpen = True Then
			NETComm1.set_Output(OutputString)
			If Err.Number > 0 Then
				MsgBox(Err.Description, MsgBoxStyle.Exclamation)
			Else
				LED2(4).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
			End If
		End If
	End Sub
	
	Private Sub frmTerm_Resize(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Resize
		'--- Resize the Term (display) control and
		'    status bar.
		Term.SetBounds(0, VB6.TwipsToPixelsY(40), ClientRectangle.Width, VB6.TwipsToPixelsY(VB6.PixelsToTwipsY(ClientRectangle.Height) - VB6.PixelsToTwipsY(StatusArea.Height) - 40))
	End Sub
	
	Private Sub frmTerm_Closed(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Closed
		Dim T As Integer
		If NETComm1.PortOpen Then
			'--- Wait 10 seconds for data to be transmitted
			T = VB.Timer() + 10
			Do While NETComm1.OutBufferCount
				System.Windows.Forms.Application.DoEvents()
				If VB.Timer() > T Then
					Select Case MsgBox("Data cannot be sent", 34)
						'--- Abort
						Case 3
							'--- Retry
						Case 4
							T = VB.Timer() + 10
							'--- Ignore
						Case 5
							Exit Do
					End Select
				End If
			Loop 
			NETComm1.PortOpen = False
		End If
		'--- If log file is open, flush and close it
		If hLogFile Then MCloseLog_Click(MCloseLog, New System.EventArgs())
		End
	End Sub
	
	Public Sub MCloseLog_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MCloseLog.Popup
		MCloseLog_Click(eventSender, eventArgs)
	End Sub
	Public Sub MCloseLog_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MCloseLog.Click
		'--- Close the log file.
		FileClose(hLogFile)
		hLogFile = 0
		MOpenLog.Enabled = True
		MCloseLog.Enabled = False
		frmTerm.DefInstance.Text = "XMComm Terminal"
	End Sub
	
	Public Sub MDial_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MDial.Popup
		MDial_Click(eventSender, eventArgs)
	End Sub
	Public Sub MDial_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MDial.Click
		On Error Resume Next
		Static Num As String
		Dim SaveThreshold As Short
		Dim Buffer As String
		'--- Get a number from the user.
		Num = InputBox("Enter Phone Number:", "Dial Number", Num)
		If Num = "" Then Exit Sub
		'--- Open the port if it isn't already
		If Not NETComm1.PortOpen Then
			MOpen_Click(MOpen, New System.EventArgs())
			If Err.Number Then Exit Sub
		End If
		'--- Dial the number
		OH(True) 'use Modem Lights
		NETComm1.set_Output("ATD2DT" & Num & vbCr & vbLf)
		Status.Text = "Dialing... " & Num
		SaveThreshold = NETComm1.RThreshold
		NETComm1.RThreshold = 0 'keep all processing here
		MHangup.Enabled = True 'enable Hangup
		Do Until NETComm1.DTREnable = False
			System.Windows.Forms.Application.DoEvents()
			Buffer = Buffer & NETComm1.InputData
			If InStr(Buffer, "CONNECT") Then
				Wait(0.2) 'allow OnComm to reflect CD change
				Exit Do
			ElseIf InStr(Buffer, "NO CARRIER" & vbCr & vbLf) Then 
				MsgBox("Lost Carrier!")
				OH(False)
				Status.Text = ""
				Exit Do
			ElseIf InStr(Buffer, "ERROR" & vbCr & vbLf) Then 
				MsgBox("Check Number!")
				OH(False)
				Status.Text = ""
				Exit Do
			End If
		Loop 
		NETComm1.RThreshold = SaveThreshold
	End Sub
	
	'--- Toggle DTREnabled property
	'
	Public Sub MDTREnable_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MDTREnable.Popup
		MDTREnable_Click(eventSender, eventArgs)
	End Sub
	Public Sub MDTREnable_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MDTREnable.Click
		NETComm1.DTREnable = Not NETComm1.DTREnable
		MDTREnable.Checked = NETComm1.DTREnable
	End Sub
	
	Public Sub MFileExit_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MFileExit.Popup
		MFileExit_Click(eventSender, eventArgs)
	End Sub
	Public Sub MFileExit_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MFileExit.Click
		'--- Use Form_Unload since it has code to check
		'    for un sent data and open log file
		Me.Close()
	End Sub
	
	'--- Toggle DTREnable to hang up the line
	'
	Public Sub MHangup_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHangup.Popup
		MHangup_Click(eventSender, eventArgs)
	End Sub
	Public Sub MHangup_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHangup.Click
		Dim Ret As Short
		Ret = NETComm1.DTREnable 'Save current setting
		NETComm1.DTREnable = True 'Turn DTR on
		Wait(0.2)
		NETComm1.DTREnable = False 'Turn DTR off
		OH(False) 'use Modem Lights
		Wait(0.2)
		NETComm1.DTREnable = Ret 'Restore old setting
	End Sub
	
	'--- Display the value of the CDHolding property.
	'
	Public Sub MHCD_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHCD.Popup
		MHCD_Click(eventSender, eventArgs)
	End Sub
	Public Sub MHCD_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHCD.Click
		Dim Temp As String
		If NETComm1.CDHolding Then
			Temp = "True"
		Else
			Temp = "False"
		End If
		MsgBox("CDHolding = " & Temp)
	End Sub
	
	'--- Display the value of the CTSHolding property.
	'
	Public Sub MHCTS_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHCTS.Popup
		MHCTS_Click(eventSender, eventArgs)
	End Sub
	Public Sub MHCTS_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHCTS.Click
		Dim Temp As String
		If NETComm1.CTSHolding Then
			Temp = "True"
		Else
			Temp = "False"
		End If
		MsgBox("CTSHolding = " & Temp)
	End Sub
	
	'--- Display the value of the DSRHolding property.
	'
	Public Sub MHDSR_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHDSR.Popup
		MHDSR_Click(eventSender, eventArgs)
	End Sub
	Public Sub MHDSR_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MHDSR.Click
		Dim Temp As String
		If NETComm1.DSRHolding Then
			Temp = "True"
		Else
			Temp = "False"
		End If
		MsgBox("DSRHolding = " & Temp)
	End Sub
	
	'*************************************************
	'Sets the InputLen property. The InputLen property
	'determines how many bytes of data are read each
	'time Input is used to retrieve data from the
	'input buffer. Setting InputLen to 0 specifies that
	'the entire contents of the buffer should br read.
	'*************************************************
	'
	Public Sub MInputLen_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MInputLen.Popup
		MInputLen_Click(eventSender, eventArgs)
	End Sub
	Public Sub MInputLen_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MInputLen.Click
		Dim Temp As String
		On Error Resume Next
		Temp = InputBox("Enter New InputLen:", "InputLen", Str(NETComm1.InputLen))
		If Len(Temp) Then
			NETComm1.InputLen = Val(Temp)
			If Err.Number Then MsgBox(Err.Description, MsgBoxStyle.Exclamation)
		End If
	End Sub
	
	'--- Toggles the state of the port (open or closed).
	'
	Public Sub MOpen_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MOpen.Popup
		MOpen_Click(eventSender, eventArgs)
	End Sub
	Public Sub MOpen_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MOpen.Click
		On Error Resume Next
		Dim OpenFlag As Short
		NETComm1.PortOpen = Not NETComm1.PortOpen
		If Err.Number Then MsgBox(Err.Description, MsgBoxStyle.Exclamation)
		OpenFlag = NETComm1.PortOpen
		MOpen.Checked = OpenFlag
		MSendText.Enabled = OpenFlag
		MHangup.Enabled = OpenFlag
	End Sub
	
	Public Sub MOpenLog_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MOpenLog.Popup
		MOpenLog_Click(eventSender, eventArgs)
	End Sub
	Public Sub MOpenLog_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MOpenLog.Click
		Dim replace_Renamed As Short
		Dim Ret As Short
		Dim Temp As String
		On Error Resume Next
		'--- Get Log File name from the user
		OpenLog.DialogTitle = "Open Communications Log File"
		OpenLog.Filter = "Log Files (*.LOG)|*.log|All Files (*.*)|*.*"
		Do 
			OpenLog.FileName = ""
			OpenLog.Action = 1
			If Err.Number <> 0 Then Exit Sub
			Temp = OpenLog.FileName
			
			'--- If file already exists, do they want to
			'    overwrite or add to it.
			Ret = Len(Dir(Temp))
			If Err.Number Then
				MsgBox(Err.Description, MsgBoxStyle.Exclamation)
				Exit Sub
			End If
			If Ret Then
				replace_Renamed = MsgBox("Replace existing file - " & Temp & "?", 35)
			Else
				replace_Renamed = 0
			End If
		Loop While replace_Renamed = 2
		'--- User picked "Yes" button - Delete file.
		If replace_Renamed = 6 Then
			Kill(Temp)
			If Err.Number Then
				MsgBox(Err.Description, MsgBoxStyle.Exclamation)
				Exit Sub
			End If
		End If
		'--- Open the log file
		hLogFile = FreeFile
		FileOpen(hLogFile, Temp, OpenMode.Binary, OpenAccess.Write)
		If Err.Number Then
			MsgBox(Err.Description, MsgBoxStyle.Exclamation)
			FileClose(hLogFile)
			hLogFile = 0
			Exit Sub
		Else
			'--- Seek to the end so we append new data
			Seek(hLogFile, LOF(hLogFile) + 1)
		End If
		frmTerm.DefInstance.Text = "XMComm Terminal - " & OpenLog.FileTitle
		MOpenLog.Enabled = False
		MCloseLog.Enabled = True
	End Sub
	
	'*************************************************
	'Sets the ParityReplace property. The
	'ParityReplace property holds the character that
	'will replace any incorrect characters that are
	'received due to a parity error.
	'*************************************************
	'
	Public Sub MParRep_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MParRep.Popup
		MParRep_Click(eventSender, eventArgs)
	End Sub
	Public Sub MParRep_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MParRep.Click
		On Error Resume Next
		Dim Temp As String
		Temp = InputBox("Enter Replace Character", "ParityReplace", frmTerm.DefInstance.NETComm1.get_ParityReplace())
		frmTerm.DefInstance.NETComm1.set_ParityReplace(VB.Left(Temp, 1))
		If Err.Number Then MsgBox(Err.Description, MsgBoxStyle.Exclamation)
	End Sub
	
	'*************************************************
	'Sets the RThreshold property.  The RThreshold
	'property determines how many bytes can arrive at
	'the receive buffer before the OnComm event is
	'triggered and the CommEvent property is set to
	'comRECEIVE
	'*************************************************
	'
	Public Sub MRThreshold_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MRThreshold.Popup
		MRThreshold_Click(eventSender, eventArgs)
	End Sub
	Public Sub MRThreshold_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MRThreshold.Click
		Dim Temp As String
		On Error Resume Next
		Temp = InputBox("Enter New RThreshold:", "RThreshold", Str(NETComm1.RThreshold))
		If Len(Temp) Then
			NETComm1.RThreshold = Val(Temp)
			If Err.Number Then MsgBox(Err.Description, MsgBoxStyle.Exclamation)
		End If
	End Sub
	
	'*************************************************
	'The OnComm event is used for trapping
	'communications events and errors.
	'*************************************************
	'
	Private Sub NETComm1_OnComm(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles NETComm1.OnComm
		Static EVMsg As String
		Static ERMsg As String
		Static Ret As Short
		'--- Branch according to the CommEvent Prop..
		Select Case NETComm1.CommEvent
			'--- Event messages
			Case MSCommLib.OnCommConstants.comEvReceive
				ShowData((NETComm1.InputData))
				
			Case MSCommLib.OnCommConstants.comEvCTS
				EVMsg = "Change in CTS Detected"
			Case MSCommLib.OnCommConstants.comEvDSR
				EVMsg = "Change in DSR Detected"
			Case MSCommLib.OnCommConstants.comEvCD
				EVMsg = "Change in CD Detected.  CD = "
				If NETComm1.CDHolding Then
					EVMsg = EVMsg & "True."
					OH(True) 'use Modem Lights
				Else
					OH(False) 'use Modem Lights
					EVMsg = EVMsg & "False."
				End If
			Case MSCommLib.OnCommConstants.comEvRing
				EVMsg = "The Phone is Ringing"
			Case MSCommLib.OnCommConstants.comEvEOF
				EVMsg = "End of File Detected"
				'--- Error messages
			Case MSCommLib.CommEventConstants.comEventBreak
				EVMsg = "Break Received"
			Case MSCommLib.CommEventConstants.comEventCTSTO
				ERMsg = "CTS Timeout"
			Case MSCommLib.CommEventConstants.comEventDSRTO
				ERMsg = "DSR Timeout"
			Case MSCommLib.CommEventConstants.comEventFrame
				EVMsg = "Framing Error"
			Case MSCommLib.CommEventConstants.comEventOverrun
				ERMsg = "Overrun Error"
			Case MSCommLib.CommEventConstants.comEventCDTO
				ERMsg = "Carrier Detect Timeout"
			Case MSCommLib.CommEventConstants.comEventRxOver
				ERMsg = "Receive Buffer Overflow"
			Case MSCommLib.CommEventConstants.comEventRxParity
				EVMsg = "Parity Error"
			Case MSCommLib.CommEventConstants.comEventTxFull
				ERMsg = "Transmit Buffer Full"
			Case Else
				ERMsg = "Unknown error or event"
		End Select
		If Len(EVMsg) Then
			'--- Display event messages in label
			Status.Text = EVMsg
			EVMsg = ""
		ElseIf Len(ERMsg) Then 
			'--- Display error messages in an alert
			'    message box.
			Beep()
			Ret = MsgBox(ERMsg, MsgBoxStyle.OKCancel, "Press Cancel to Quit, Ok to ignore.")
			ERMsg = ""
			'--- If Cancel (2) was pressed
			If Ret = MsgBoxResult.Cancel Then
				NETComm1.PortOpen = False 'Close the port and quit
			End If
		End If
	End Sub
	
	Public Sub MSendText_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSendText.Popup
		MSendText_Click(eventSender, eventArgs)
	End Sub
	Public Sub MSendText_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSendText.Click
		Dim Temp As String
		On Error Resume Next
		Dim BSize, hSend, Ret As Short
		Dim LF As Integer
		If NETComm1.CDHolding = False Then
			Ret = MsgBox("Carrier has not been established.  Select OK to continue to send the file.", MsgBoxStyle.OKCancel)
			If Ret = MsgBoxResult.Cancel Then Exit Sub
		End If
		MSendText.Enabled = False
		'--- Get Text File name from the user
		OpenLog.DialogTitle = "Send Text File"
		OpenLog.Filter = "Text Files (*.TXT)|*.txt|All Files (*.*)|*.*"
		Do 
			OpenLog.FileName = ""
			OpenLog.Action = 1
			If Err.Number <> 0 Then Exit Sub
			Temp = OpenLog.FileName
			
			'--- If file doesn't exist, go back

			Ret = Len(Dir(Temp))
			If Err.Number > 0 Then
				MsgBox(Err.Description, MsgBoxStyle.Exclamation)
				MSendText.Enabled = True
				Exit Sub
			End If
			If Ret Then
				Exit Do
			Else
				MsgBox(Temp & " not found!", MsgBoxStyle.Exclamation)
			End If
		Loop 
		'--- Open the log file
		hSend = FreeFile
		FileOpen(hSend, Temp, OpenMode.Binary, OpenAccess.Read)
		If Err.Number Then
			MsgBox(Err.Description, MsgBoxStyle.Exclamation)
		Else
			'--- Display the Cancel dialog box
			CancelSend = False
			frmCanSend.DefInstance.Label1.Text = "Transmitting Text File - " & Temp
			frmCanSend.DefInstance.Show()
			
			'--- Read the file in blocks the size of our
			'    transmit buffer.
			BSize = NETComm1.OutBufferSize
			LF = LOF(hSend)
			Do Until EOF(hSend) Or CancelSend
				'--- Don't read too much at the end
				If LF - Loc(hSend) <= BSize Then
					BSize = LF - Loc(hSend) + 1
				End If
				'--- Read a block of data
				Temp = Space(BSize)
				FileGet(hSend, Temp)
				
				'--- Transmit the block
				CommOutput(Temp) 'use Modem Lights
				If Err.Number Then
					MsgBox(Err.Description, MsgBoxStyle.Exclamation)
					Exit Do
				End If
				'--- Wait for all the data to be sent
				Do 
					System.Windows.Forms.Application.DoEvents()
				Loop Until NETComm1.OutBufferCount = 0 Or CancelSend
			Loop 
		End If
		FileClose(hSend)
		MSendText.Enabled = True
		CancelSend = True
		frmCanSend.DefInstance.Hide()
	End Sub
	
	Public Sub MSettings_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSettings.Popup
		MSettings_Click(eventSender, eventArgs)
	End Sub
	Public Sub MSettings_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSettings.Click
        '--- Show the communications settings form
        Dim ConfigScrn = New frmConfigScrn()
        ConfigScrn.showdialog()
		Term.Focus()
	End Sub
	
	'*************************************************
	'Sets the SThreshold property. The SThreshold
	'property determines how many characters (at most)
	'have to be waiting in the output buffer before
	'the CommEvent property is set to EV_SEND and the
	'OnComm event is triggered.
	'*************************************************
	'
	Public Sub MSThreshold_Popup(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSThreshold.Popup
		MSThreshold_Click(eventSender, eventArgs)
	End Sub
	Public Sub MSThreshold_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MSThreshold.Click
		Dim Temp As String
		On Error Resume Next
		Temp = InputBox("Enter New SThreshold Value", "SThreshold", Str(NETComm1.SThreshold))
		If Len(Temp) Then
			NETComm1.SThreshold = Val(Temp)
			If Err.Number Then MsgBox(Err.Description, MsgBoxStyle.Exclamation)
		End If
	End Sub
	
	Private Sub OH(ByRef OffHook As Short)
		If OffHook = True Then
			LED2(2).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(2).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
			MHangup.Enabled = False
		End If
	End Sub
	
	'**************************************************
	'Adds data to the Term control's .Text property.
	'Also filters control characters such as Back Space
	'Carriage Return and Line Feed, and writes data to
	'an open log file.
	'
	'Back Space chars. delete the character to the left,
	'either in the .Text property, or the passed string.
	'Line Feed characters are appended to all Carriage
	'Returns.  The size of the Term control's Text
	'property is also monitored so that it never
	'exceedes 16384 characters.
	'**************************************************
	'
	Private Sub ShowData(ByRef Dta As String)
		On Error Resume Next
		Dim Nd, I As Short
		LED2(3).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF) 'use Modem Lights
		'--- Make sure the existing text doesn't get
		'    too large.
		Nd = Len(Term.Text)
		If Nd >= 16384 Then
			Term.Text = Mid(Term.Text, 4097)
			Nd = Len(Term.Text)
		End If
		'--- Point to the end of Term's data
		Term.SelectionStart = Nd
		'--- Filter/handle Back Space characters
		Do 
			I = InStr(Dta, Chr(8))
			If I Then
				If I = 1 Then
					Term.SelectionStart = Nd - 1
					Term.SelectionLength = 1
					Dta = Mid(Dta, I + 1)
				Else
					Dta = VB.Left(Dta, I - 2) & Mid(Dta, I + 1)
				End If
			End If
		Loop While I
		'--- Eliminate Line Feeds (put back below)
		Do 
			I = InStr(Dta, vbLf)
			If I Then
				Dta = VB.Left(Dta, I - 1) & Mid(Dta, I + 1)
			End If
		Loop While I
		'--- Make sure all Carriage Returns have a
		'    Line Feed
		I = 1
		Do 
			I = InStr(I, Dta, vbCr)
			If I Then
				Dta = VB.Left(Dta, I) & vbLf & Mid(Dta, I + 1)
				I = I + 1
			End If
		Loop While I
		'--- Add the filtered data to .Text
		Term.SelectedText = Dta
		'--- Log data to file if requested
		If hLogFile Then
			I = 2
			Do 
				Err.Clear()
				FilePut(hLogFile, Dta)
				If Err.Number <> 0 Then
					I = MsgBox(Err.Description, MsgBoxStyle.OKCancel)
					If I = MsgBoxResult.Cancel Then
						MCloseLog_Click(MCloseLog, New System.EventArgs())
					End If
				End If
			Loop While I <> MsgBoxResult.Cancel
		End If
	End Sub
	
	Private Sub StatusTimer_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles StatusTimer.Tick
		Static ClearCount As Short
		Static StatusMessage As String
		If Status.Text <> "" Then
			If Status.Text = StatusMessage Then
				ClearCount = ClearCount + 1
				If ClearCount >= 100 Then 'Clear Status after 15 seconds
					ClearCount = 0
					Status.Text = ""
				End If
			Else
				StatusMessage = Status.Text
				ClearCount = 0
			End If
		End If
		If Val(NETComm1.get_Settings()) > 1200 Then
			LED2(0).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(0).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
		End If
		If NETComm1.DTREnable = True Then
			LED2(5).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(5).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
		End If
		
		If NETComm1.OutBufferCount > 0 Then
			LED2(4).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(4).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
		End If
		If NETComm1.InBufferCount > 0 Then
			LED2(3).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(3).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
		End If
		If NETComm1.CDHolding = True Then
			LED2(1).BackColor = System.Drawing.ColorTranslator.FromOle(&HFF)
		Else
			LED2(1).BackColor = System.Drawing.ColorTranslator.FromOle(&H0)
		End If
	End Sub
	
	'*************************************************
	'Key strokes trapped here are sent to the Comm
	'control where they are echoed back via the
	'OnComm/comRECEIVE event, and displayed
	'through the ShowData procedure.
	'*************************************************
	'
	Private Sub Term_KeyPress(ByVal eventSender As System.Object, ByVal eventArgs As System.Windows.Forms.KeyPressEventArgs) Handles Term.KeyPress
		Dim KeyAscii As Short = Asc(eventArgs.KeyChar)
		'--- If the port is opened,
		If NETComm1.PortOpen Then
			'--- Send the key stroke to the port
			CommOutput(Chr(KeyAscii)) 'use Modem Lights
			'--- Unless Echo is on, there is no need to
			'    let the Text control display the key.
			If Not Echo Then KeyAscii = 0
		Else
			KeyAscii = 0
		End If
		If KeyAscii = 0 Then
			eventArgs.Handled = True
		End If
	End Sub
	
	Private Sub Timer1_Tick(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Timer1.Tick
		Timer1.Enabled = False
	End Sub
	
	Private Sub Wait(ByRef WaitTime As Single)
		Timer1.Interval = WaitTime * 1000
		Timer1.Enabled = True
		Do Until Timer1.Enabled = False
			System.Windows.Forms.Application.DoEvents()
		Loop 
	End Sub
End Class